# standbasisv2
Standbasis Repo for Grace and I

# How to Run

1. In the root directory of the project, run "composer install" or if you confused about composer, read this-> https://getcomposer.org/doc/01-basic-usage.md

2. Then go the public directory, you then run "npm install", it will install all html and JS dependencies that work with my template

3. After all dependencies are installed, Run "php artisan serve" within the root directory. (remember to install XAMP and add the bin directory of PHP into the windows Path.)
