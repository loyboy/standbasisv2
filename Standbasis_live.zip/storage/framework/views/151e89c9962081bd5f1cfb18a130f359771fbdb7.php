<?php $__env->startSection('teacher'); ?>
  <!--gx-wrapper-->
  <div class="gx-wrapper">

<div class="animated slideInUpTiny animation-duration-3">

    <div class="page-heading">
        <h2 class="title">View Attendance Data</h2>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <div class="gx-card">
                <div class="gx-card-header">
                    <h3 class="card-heading">All attendances done by you up to date</h3>
                </div>
               
                <div class="gx-card-body">
                
                    <div class=""> 
                            <div class="form-group row">
                                <label class="col-md-4 col-sm-3 control-label">Select Date</label>
                                    <div class="col-md-4 col-sm-6">
                                        <input type="date" value="" class="form-control" onchange="getAttendanceOnChange()" id="attdate"/>
                                    </div>
                            </div>
                    </div>

                    <div class="table-responsive">

                        <table id="mydatatable" class="table table-striped table-bordered table-hover">
                            <thead>
                            <tr>
                                <th>S/N</th>
                                <th>Subject & Class</th>
                                <th>Expected Time</th>
                                <th>Actual Time</th>
                                <th>Performance</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody id="tbody1">
                                <tr> <td colspan="6" style="text-align: center;"> Attendance data will display here...  </td> </tr>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</div>

                                <div class="modal fade" id="getattendance" tabindex="-1" role="dialog" aria-labelledby="backupAccount" style="display: none;" aria-hidden="true">
                                    <div class="modal-dialog modal-lg" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header bg-info border-0">
                                                <h4 class="modal-title" id="mytitle"> </h4>
                                                <button type="button" class="close" data-dismiss="modal">
                                                    <span aria-hidden="true">&times;</span><span class="sr-only">Close</span>    
                                                </button>
                                            </div>

                                            <div class="modal-body"> <!-- -->                                             
                                               
                                                <div class="row">
                                                    <div class="col-md-12"> 
                                                        <img id="attimg" width="480" height="300" style="margin: 0 auto;"/> <br/>
                                                        <div style = "padding: 5px; margin-top: 50px; overflow-y: scroll; max-height:300px;" id="myatt_table" > </div>
                                                    </div>                                                   
                                                </div>
                                                            
                                            </div>

                                            <div class="modal-footer">
                                                    <button type="button" class="btn btn-info btn-block" data-dismiss="modal">Close</button>                    
                                            </div>
                                        
                                        </div>                                        
                                    </div>
                                </div>
<!--/gx-wrapper-->
<script>    
    let teacher = <?php echo e(Auth::user()->teacher_id); ?>;
    let token = '<?php echo e(Auth::user()->api_token); ?>';
    
    let xhr = new XMLHttpRequest();
        xhr.open('POST', '/attendances_viewAtt/'+teacher);
        xhr.responseType = 'json';
        let formData = new FormData();
        formData.append("api_token", token);
        xhr.send(formData);

        xhr.onload = function() {
            let responseObj = xhr.response;
            if (responseObj.status === "Failed"){
                alert(responseObj.message);
                return;
            }
            
            let attend = responseObj.data;
            var i = 0;
            //$('#mydatatable').find('tbody').empty();

            for ( let datarow of attend ){ 
                var tablex = document.getElementById('tbody1').insertRow(i);               
                //tablex.;
                var cell0 = tablex.insertCell(0);
                var cell1 = tablex.insertCell(1);
                var cell2 = tablex.insertCell(2);
                var cell3 = tablex.insertCell(3);
                var cell4 = tablex.insertCell(4);
                var cell5 = tablex.insertCell(5);
                
                tablex.className = "datarow";
                cell0.innerHTML = "<strong>"+ (i + 1) + "</strong>";
                cell1.innerHTML = "<strong>"+ datarow.Subclass + "</strong>";
                cell2.innerHTML = "<strong>"+ datarow.ExpTime + "</strong>";
                cell3.innerHTML = "<strong>"+ datarow.ActTime + "</strong>";
                cell4.innerHTML = "<strong>"+ datarow.Perf + "%" + "</strong>";
                cell5.innerHTML = "<strong> <a class='btn btn-primary' onclick='showAttendance("+datarow.id+")' > View Attendance </a> </strong>";
               //cell3.innerHTML = "<div class='form-checkbox'> <input type='checkbox' disabled name='excused[]' id='stad" + datarow.PupilID + "' class='excusedform' value='yes'> </div>";
                i++;
            }
        } 
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('myscript'); ?>
<script>
    $(document).ready(function(){
   
    });
    function showAttendance(idx){
         $.ajax({
            type: "POST",           
            url: "/attendances_viewAttLog/"+idx,
            dataType: "json",
            data: {
                api_token:token 
            }, 
            success: function(data) {               
              var stx = JSON.parse(JSON.stringify(data));
              $('#attimg').attr("src",stx._IMAGE);
             // $('#comments_attendance').html(stx._COMMENT);
              $('#myatt_table').html(stx._TEXT);
              $('#mytitle').html(stx._TITLE);
              $('#getattendance').modal({
                     backdrop: 'static',
                     keyboard: false
                 },'show');
             console.log("Do something in Attendacne"); 
               
            }
        });     
    }

    function getAttendanceOnChange(){
        let datebox = $('#attdate').val();
        let xhr = new XMLHttpRequest();
        xhr.open('POST', '/attendances_viewAtt/'+teacher);
        xhr.responseType = 'json';
        let formData = new FormData();
        formData.append("_date", datebox);
        formData.append("api_token", token);
        document.getElementById('loading').style.display = 'block';
        xhr.send(formData);

        xhr.onload = function() {
            let responseObj = xhr.response;
            if (responseObj.status === "Failed"){
                alert(responseObj.message);
                document.getElementById('loading').style.display = 'none';
                return;
            }
            
            let attend = responseObj.data;
            var i = 0;
            $('#tbody1').empty();
            for ( let datarow of attend ){ 
                var tablex = document.getElementById('tbody1').insertRow(i);
               // tablex.empty();
               // tablex;
                var cell0 = tablex.insertCell(0);
                var cell1 = tablex.insertCell(1);
                var cell2 = tablex.insertCell(2);
                var cell3 = tablex.insertCell(3);
                var cell4 = tablex.insertCell(4);
                var cell5 = tablex.insertCell(5);
              
                tablex.className = "datarow";
                cell0.innerHTML = "<strong>"+ (i + 1) + "</strong>";
                cell1.innerHTML = "<strong>"+ datarow.Subclass + "</strong>";
                cell2.innerHTML = "<strong>"+ datarow.ExpTime + "</strong>";
                cell3.innerHTML = "<strong>"+ datarow.ActTime + "</strong>";
                cell4.innerHTML = "<strong>"+ datarow.Perf + "%" + "</strong>";
                cell5.innerHTML = "<strong> <a class='btn btn-primary' onclick='showAttendance("+datarow.id+")' > View Attendance </a> </strong>";
               //cell3.innerHTML = "<div class='form-checkbox'> <input type='checkbox' disabled name='excused[]' id='stad" + datarow.PupilID + "' class='excusedform' value='yes'> </div>";
                i++;
            }
            document.getElementById('loading').style.display = 'none';
        } 
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\EBU\Documents\TransferToComputer\standbasisv1\resources\views/teacher/attendance/view.blade.php ENDPATH**/ ?>