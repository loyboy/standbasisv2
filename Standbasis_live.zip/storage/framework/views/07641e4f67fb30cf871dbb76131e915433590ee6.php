<?php $__env->startSection('content'); ?>
            <!--gx-wrapper-->
            <div class="gx-wrapper">
                <div class="login-container d-flex justify-content-center align-items-center animated slideInUpTiny animation-duration-3">
                    <div class="login-content">

                        <div class="login-header">
                           <!-- <a class="site-logo" href="javascript:void(0)" title="Standbasis">
                                <img src="http://via.placeholder.com/140x24" alt="Standbasis" title="standbasis">
                            </a> -->
                           <h3> Standbasis </h3>
                        </div>
                        
                        <div class="login-form">
                            <form method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>
                                <fieldset>
                                    <div class="form-group">
                                        <input id="username" type="text" class="form-control <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="username" value="<?php echo e(old('username')); ?>" required autocomplete="username" autofocus placeholder="Enter your Username">

                                        <?php if ($errors->has('username')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('username'); ?>
                                           <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>

                                    <div class="form-group">
                                    <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="current-password" placeholder="Enter your Password">

                                        <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>                                            
                                            <small class="form-text text-muted"><?php echo e($message); ?>.</small>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                       
                                    </div>
                                   

                                   <!-- <div class="form-group text-row-between">
                                        <div class="custom-control custom-checkbox mr-2">
                                            <input type="checkbox" class="custom-control-input" id="customControlInline">
                                            <label class="custom-control-label" for="customControlInline">Remember me</label>
                                        </div>                                        
                                    </div> -->
                                   <!-- <a href="javascript:void(0)" class="gx-btn gx-btn-rounded gx-btn-primary">Sign In</a> -->
                                    <button type="submit" class="gx-btn gx-btn-rounded gx-btn-primary">
                                       Sign In
                                    </button>
                                </fieldset>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!--/gx-wrapper-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Emmaloy\Documents\PHPProjects\standbasisv1_01102019\resources\views/auth/login.blade.php ENDPATH**/ ?>