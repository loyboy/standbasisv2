(function ($) {
    "use strict";
    
    $('.module-list-info').on('click', function () {
        window.location = "mail-inner.html";
    });

})(jQuery);